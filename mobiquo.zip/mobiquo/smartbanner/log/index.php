<?php

/**
 * this is dummy file. In this folder will reside the Tapatalk plugin internal error log
 */
