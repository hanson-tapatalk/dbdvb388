<?php

defined('CWD1') or exit;
defined('IN_MOBIQUO') or exit;

function update_profile($xmlrpc_params)
{
    global $vbulletin;

    if (!$vbulletin->userinfo['userid']) {

    }

    $params = php_xmlrpc_decode($xmlrpc_params);
    $custom_fields = $params[0];

    foreach ($variable as $key => $value) {
        # code...
    }

    $userdata =& datamanage_init('User', $vbulletin, ERRTYPE_ARRAY);
    $userdata->set_userfields($custom_fields);

    $userdata->save();
}